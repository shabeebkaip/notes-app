import React from 'react'

export default function Home(props){
    return (
        <h2>Welcome Home App</h2>
    )

}