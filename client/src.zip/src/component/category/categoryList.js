import React from 'react'
import axios from '../../config/axios'


export default class CategoryList extends React.Component{
    constructor(){
        super()
        this.state={
            categories:[],
            text:"",
            isEdit:true,
            id:''
        }
    }

    componentDidMount=()=>{
        axios.get('/categories',{
            headers:{
            'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            const categories=response.data
            this.setState({categories})
        })
    }

    handleRemove=(e)=>{
        const id=e.target.value
        // console.log(e.target.value)
        const remove=window.confirm('are you sure?')
            if(remove){
        axios.delete(`/categories/${id}`,{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
        // console.log(response.data)
            window.location.reload()
        })
    }
    }

    handleAdd=()=>{
        axios.post('/categories',{"name":this.state.text},{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            window.location.reload()
        })
    }

    handleChange=(e)=>{
        const text=e.target.value
        this.setState({text})
    }

    editHandle=(id,name)=>{
        // console.log(id,name)
        this.setState({text:name,id, isEdit:false})
    }

    saveHandle=()=>{
        const id=this.state.id
        axios.put(`/categories/${id}`,{"name":this.state.text},{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
        console.log(response.data)
        window.location.reload()        
        })
    }

    render(){
        return (
            <div>
                <h2>Category List -{this.state.categories.length}</h2>
                <ul>
                {   
                    this.state.categories.map(category=>{
                       return <li key={category._id}>{category.name}<button value={category._id}onClick={this.handleRemove}>remove</button><button onClick={()=>this.editHandle(category._id,category.name)}>Edit</button></li>
                    })                    
                }
                </ul>
                <br/>
                
                <input type='text' value={this.state.text} onChange={this.handleChange}/>
                {this.state.isEdit ?
                (<button onClick={this.handleAdd}>Add</button>):(<button onClick={this.saveHandle}>save</button>)
                }
            </div>
        )
    }
}