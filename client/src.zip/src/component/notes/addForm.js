import React from 'react'
import axios from '../../config/axios'
import Form from './Form'

export default class AddForm extends React.Component{
    submitHandle=(formData)=>{
        axios.post('/notes',formData,{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            // window.location.reload()
            this.props.history.push('/notes')
        })
    }
    render(){
        return (
            <div>
                <h2>Add Form</h2>
                <Form submitHandle={this.submitHandle}/>
            </div>
        )
    }
}