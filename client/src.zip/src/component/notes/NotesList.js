import React from 'react'
import axios from '../../config/axios'
import {Link} from 'react-router-dom'

export default class NotesList extends React.Component{
    constructor(){
        super()
        this.state={
            notes:[],
            categories:[],
            isNote:true
        }
    }

    componentDidMount=()=>{
        axios.get('/notes',{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            const notes=response.data
            this.setState({notes})
        })
        .catch(err=>{
            alert(err)
        })
    }

    handleRemove=(e)=>{
        const remove=window.confirm('are you sure?')
        if(remove){
        axios.delete(`/notes/${e.target.value}`,{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            // alert(response.data)
            window.location.reload()

        })
    }
    }

    render(){
        return (
            <div>
                <h2>Notes List -{this.state.notes.length}</h2>
                <button><Link to='/notes/add'>Add</Link></button>
                        {this.state.notes.map(note=>{
                           return ( <div key={note._id}>
                                <h2>{note.title}</h2>
                                <h4>{note.categoryId.name}</h4>
                                <p>{note.description}</p>
                                <button><Link to={`/notes/edit/${note._id}`}>Edit</Link></button><button value={note._id} onClick={this.handleRemove}>Remove</button>
                                <hr/>
                            </div>)
                        })}
            </div>
        )
    }
}