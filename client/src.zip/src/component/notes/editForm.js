import React from 'react'
import axios from '../../config/axios'
import Form from './Form'

export default class EditForm extends React.Component{
    constructor(){
        super()
        this.state={
            note:{}
        }
    }

    componentDidMount(){
        axios.get(`/notes/${this.props.match.params.id}`,{
            headers:{
            'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            const note=response.data
            this.setState({note})
            // console.log(response.data)
        })
    }
    submitHandle=(formData)=>{
        axios.put(`/notes/${this.props.match.params.id}`,formData,{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            // window.location.reload()
            this.props.history.push('/notes')
        })
    }
    render(){
        return (
            <div>
                <h2>Edit Form</h2>
                {Object.keys(this.state.note).length!==0 && <Form note={this.state.note} submitHandle={this.submitHandle}/>}
            </div>
        )
    }
}