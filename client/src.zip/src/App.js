import React from 'react'
import Home from './component/common/Home'
import Login from './component/users/Login'
import Register from './component/users/Register'

import axios from './config/axios'

import NotesList from './component/notes/NotesList'
import AddForm from './component/notes/addForm'
import EditForm from './component/notes/editForm'

import CategoryList from './component/category/categoryList'

import {BrowserRouter , Route,Link} from 'react-router-dom'

function handleClick(){
  axios.delete('/users/logout',{
    headers:{
      'x-auth':localStorage.getItem('authToken')
    }
  })
  .then(response=>{
    alert(response.data.notice)
    localStorage.removeItem('authToken')
    window.location.href='/'
  })
}
function App() {
  return (
    <BrowserRouter>
    <div>
      <h2>Notes App</h2>
      <ul>
      <Link to='/'>Home</Link>|
      {
        localStorage.getItem('authToken')?(
          <div>
            <li><Link to='/notes'>Notes</Link></li>
            <li><Link to='/categories'>Category</Link></li>
            <li><Link to='#' onClick={handleClick}>logout</Link></li>
          </div>):(<div>
            <li><Link to='/users/register'>register</Link></li>
            <li><Link to='/users/login'>login</Link></li>
          </div>
        )
      }
      

      <Route path='/' component={Home} exact={true}/>
      <Route path='/users/register' component={Register}/>
      <Route path='/users/login' component={Login}/>

      <Route path='/categories' component={CategoryList}/>

      
      <Route path='/notes' component={NotesList} exact={true}/>
      <Route path='/notes/add' component={AddForm}/>
      <Route path='/notes/edit/:id' component={EditForm}/>



      </ul>

    </div>
    </BrowserRouter>
  )
}

export default App;
